![example](https://raw.githubusercontent.com/dericeira/Simple-Chat-Socket.io/master/example.gif)

## Resume
Simple-Chat-Socket.io is a chat script created with NodeJS and Socket.io.

## How to test
Run app.js as a node server (node app.js). Open index.html in your browser, and start chat.

## Contributors: What to implement?
Users online, direct message, etc.


## License
(The MIT License)

Copyright (c) 2016 [Daniel Campos](d.ericeira@hotmail.com)